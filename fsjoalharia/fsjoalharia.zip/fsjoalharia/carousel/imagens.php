
<?php $charming_1 = "../img/casamento/charming_1.jpg";
$charming_2 = "../img/casamento/charming_2.jpg";
$classic_1 = "../img/casamento/classic_1.jpg";
$classic_2 = "../img/casamento/classic_2.jpg";
$gracious_1 = "../img/casamento/gracious_1.jpg";
$gracious_2 = "../img/casamento/gracious_2.jpg";
$immortal_1 = "../img/casamento/immortal_1.jpg";
$immortal_2 = "../img/casamento/immortal_2.jpg";
$pure_1 = "../img/casamento/pure_1.jpg";
$pure_2 = "../img/casamento/pure_2.jpg";
$sense_1 = "../img/casamento/sense_1.jpg";
$sense_2 = "../img/casamento/sense_2.jpg";?>