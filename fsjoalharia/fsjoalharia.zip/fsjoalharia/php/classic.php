<?php $title = 'Classic';
$currentPage = 'classic';
include('../elements/head.php');
include('../elements/navbar.php');?>

<?php include('../carousel/classic.php');?>

<center>
        <h3>CLASSIC RING</h3>
        <h4>Lorem ipsum dolor sit amet consectetur adipisicing elit.<br>
            Ipsum quisquam facere non qui molestiae quidem<br>
            sequi a porro ipsa nemo expedita, sint debitis! <br>
            Dignissimos consectetur asperiores, libero recusandae
            quibusdam modi?</h4>
            <br>
            <h5>168 € | Preço por par</h5>
            <br>
            <h6>Prata 925 | Zircónia</h6>
            <p>Peso: 10.93 | QUILATE: 0.4 | QTD Pedras: 40 | Diâmetro: 1.3 mm</p>
            <a href='produtos.php'> Voltar</a><br>
    </center>

    <?php include('../elements/footer.php');?>