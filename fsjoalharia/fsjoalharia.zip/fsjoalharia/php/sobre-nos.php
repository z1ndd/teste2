<?php $title = 'Sobre Nós';
      $currentPage = 'sobreNos';
      include('../elements/head.php');
      include('../elements/navbar.php'); ?>

<body>
    <section class="about-us" style="width: 75%; margin-left: 12.5%">
        <h1 id="about_us">Sobre nós</h1>
        <p>
            Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC. Richard McClintock looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word
            in classical literature, discovered the undoubtable source.
            <br /><br /> Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC. Richard McClintock looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through
            the cites of the word in classical literature, discovered the undoubtable source. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fugit exercitationem accusantium dolorum est dolor iusto nisi itaque repellendus in sunt, fuga architecto
            quisquam nemo totam delectus animi eos.
        </p>


        <center>
            <table class="table" style="width: 75%">
                <thead>
                    <tr>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><img src="../img/AboutUs1.jpg" alt="Diamante1" style="width:50%" class="rounded float-end" alt="..."> </td>
                        <td><img src="../img/AboutUs3.jpg" alt="Diamante2" style="width:50%" class="rounded float-end" alt="..."></td>
                        <td><img src="../img/AboutUs2.jpg" alt="Diamante3" style="width:50%" class="rounded float-end" alt="..."></td>
                        </tr>
                </tbody>
            </table>
        </center>
        <p>
            Architecto, rerum? Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum facere impedit dolor ea hic, earum autem. Et nam explicabo ea qui! Esse cumque quaerat ut est repellat asperiores perferendis assumenda necessitatibus debitis nisi atque,
            repellendus quod excepturi, tenetur nesciunt quo? Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis eum rem ratione possimus eaque, quibusdam consequatur doloribus reiciendis nesciunt nisi molestias temporibus sunt explicabo
            facilis facere odio maiores suscipit, laudantium expedita laboriosam tenetur eligendi. Voluptatum molestiae aliquam dignissimos omnis quos aspernatur veritatis, debitis facilis hic maiores dicta nesciunt ut nam deserunt id sed placeat fugiat
            dolore? Tempore, quae? </p>
    </section>
    

   
    <?php include "../elements/footer.php"; ?>
</body>
</html>