<?php $title = 'Gracious';
$currentPage = 'gracious';
include('../elements/head.php');
include('../elements/navbar.php');?>


<?php include('../carousel/gracious.php');?>

<center>
        <h3>GRACIOUS RING</h3>
        <h4>Lorem ipsum dolor sit amet consectetur adipisicing elit.<br>
            Ipsum quisquam facere non qui molestiae quidem<br>
            sequi a porro ipsa nemo expedita, sint debitis! <br>
            Dignissimos consectetur asperiores, libero recusandae
            quibusdam modi?</h4>
            <br>
            <h5>785 € | Preço por par</h5>
            <br>
            <h6>Ouro 585 Branco & Amarelo | Zircónia</h6>
            <p>Peso: 13.45g | QUILATE: 0.22 | QTD Pedras: 1 | Diâmetro: 1.8 mm</p>
            <a href='produtos.php'> Voltar</a><br>
    </center>

    <?php include('../elements/footer.php');?>