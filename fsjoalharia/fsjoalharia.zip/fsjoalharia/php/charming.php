<?php $title = 'Charming';
$currentPage = 'charming';
include('../elements/head.php');
include('../elements/navbar.php');?>


<?php include('../carousel/charming.php');?>

<center>
        <h3>CHARMING RING</h3>
        <h4>Lorem ipsum dolor sit amet consectetur adipisicing elit.<br>
            Ipsum quisquam facere non qui molestiae quidem<br>
            sequi a porro ipsa nemo expedita, sint debitis! <br>
            Dignissimos consectetur asperiores, libero recusandae
            quibusdam modi?</h4>
            <br>
            <h5>272 € | Preço por par</h5>
            <br>
            <h6>Prata 925 | Zircónia</h6>
            <p>Peso: 8.12g | QUILATE: 0.106 | QTD Pedras: 2 | Diâmetro: 3.0 mm</p>
            <a href='produtos.php'> Voltar</a><br>
    </center>

    <?php include('../elements/footer.php');?>