<?php $title = 'Lightning';
$currentPage = 'lightning';
include('../elements/head.php');
include('../elements/navbar.php');?>

<center>
<img src="../img/anel-de-prata-lightning.jpg" width="30%">
        <h3>Anel de Prata Lighting</h3>
        <h4>Lorem ipsum dolor sit amet consectetur adipisicing elit.<br>
            Ipsum quisquam facere non qui molestiae quidem<br>
            sequi a porro ipsa nemo expedita, sint debitis! <br>
            Dignissimos consectetur asperiores, libero recusandae
            quibusdam modi?</h4>
            <br>
            <h5>65 € | Preço Un.</h5>
            <br>
            <h6>Prata 925</h6>
            <p>Peso: 23.6g | Banho de Óxido | Largura: 4.1 mm</p>
            <a href='produtos.php'> Voltar</a><br>
    </center>

    <?php include('../elements/footer.php');?>