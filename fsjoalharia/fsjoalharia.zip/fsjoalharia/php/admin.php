<?php   $title = 'Admin';
        $currentPage = 'admin';
        include('../elements/head-admin.php');
        include('../elements/navbar-admin.php'); ?>

<body>


<?php include "../elements/footer.php"; ?>
</body>